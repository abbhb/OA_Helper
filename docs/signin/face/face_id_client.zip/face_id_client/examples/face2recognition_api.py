import atexit
import json
from io import BytesIO

import PIL
import cv2
import numpy as np
import requests
from fastapi import FastAPI, Request, UploadFile, File, HTTPException
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from starlette.responses import JSONResponse

import face_recognition
from consul_service_api import ConsulServiceApi

# 此服务用于java上传人脸直接生成最终的人脸数组数据，不用于客户端识别

consulasd = ConsulServiceApi()

def cleanup():
    print("Python程序即将退出")
    # 在这里执行清理操作，例如关闭文件、释放资源等
    consulasd.clean()

atexit.register(cleanup)

app = FastAPI()  # 创建 api 对象

templates = Jinja2Templates(directory="./templates")

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')



@app.get("/")  # 根路由
def root(request: Request):
    headers = {"Content-Type": "text/html"}

    return templates.TemplateResponse(
        "404.html",
        {"request": request, "status_code": 404, "detail": "Not Found"},
        status_code=404,
        headers=headers,
    )

@app.get('/health')
def health():
    return "服务存活"

@app.get("/say/{data}")
def say(data: str, q: int):
    return {"data": data, "item": q}


class FaceData(BaseModel):
    face_data: str
    code: int


@app.post("/face_by_upload/", response_model=FaceData)
async def face_by_upload_image(file: UploadFile = File(...)):
    # Read the file into memory
    contents = await file.read()
    ''

    image = PIL.Image.open(BytesIO(contents))
    arrays = np.array(image)
    # Convert RGB to BGR
    frame = cv2.cvtColor(arrays, cv2.COLOR_RGB2BGR)
    # 转换为灰度图像
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray_frame = cv2.equalizeHist(gray_frame)
    faces = face_cascade.detectMultiScale(gray_frame, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
    # print("faces")
    # print(faces)
    if len(faces) > 0:
        # print("1")
        # 找到最大的人脸
        max_face = max(faces, key=lambda face: face[2] * face[3])

        # 绘制矩形框标出最大的人脸位置
        x, y, w, h = max_face
        height, width, channel = frame.shape
        # print(x,y,w, h)
        # print(height, width)
        if w * h > width * height * 0.20:
            # cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
            # cv2.imwrite("tempimage1223.jpg", frame)
            # 裁剪出相应的人脸图像
            face_image = frame[y:y + h, x:x + w]
            # cv2.imwrite("tempimage444.jpg", face_image)
            unknown_face_encodings = face_recognition.face_encodings(np.array(face_image))[0]

            # test code👇
            # allface = []
            # allface.append(np.array(unknown_face_encodings))
            # imgasd = face_recognition.load_image_file("tempimage0.9133255717643947.jpg")
            # imgasd123412412 = face_recognition.load_image_file("gew20231221133340.jpg")

            # Get face encodings for any faces in the uploaded image
            # unknown_face_encodings = face_recognition.face_encodings(imgasd, model='large')

            # unknown_face_encodings1231 = face_recognition.face_encodings(imgasd123412412, model='large')
            # allface.append(np.array(np.array(unknown_face_encodings1231)[0]))
            # match_results,weizhi = face_recognition.compare_faces(allface, unknown_face_encodings[0], 0.25)
            # # 暂时阈值给0.25测试
            # print(match_results,weizhi)

            return JSONResponse(content={"code": 1, "face_data": json.dumps(unknown_face_encodings.tolist())})
    # Open the image using PIL
    # Process the image (e.g., get image size)
    # Return the processed data as JSON
    return JSONResponse(content={"code": 0})


class ImageUrl(BaseModel):
    url: str


@app.post("/face_by_oss/", response_model=FaceData)
async def face_by_oss_image(image_url: ImageUrl):
    # Read the file into memory
    try:
        response = requests.get(image_url.url)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=400, detail=f"Error downloading image: {e}")

    # 读取图像到内存中
    image = PIL.Image.open(BytesIO(response.content))
    arrays = np.array(image)
    # Convert RGB to BGR
    frame = cv2.cvtColor(arrays, cv2.COLOR_RGB2BGR)
    # 转换为灰度图像
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray_frame = cv2.equalizeHist(gray_frame)
    faces = face_cascade.detectMultiScale(gray_frame, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
    # print("faces")
    # print(faces)
    if len(faces) > 0:
        # print("1")
        # 找到最大的人脸
        max_face = max(faces, key=lambda face: face[2] * face[3])

        # 绘制矩形框标出最大的人脸位置
        x, y, w, h = max_face
        height, width, channel = frame.shape
        # print(x,y,w, h)
        # print(height, width)
        if w * h > width * height * 0.20:
            # cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
            # cv2.imwrite("tempimage1223.jpg", frame)
            # 裁剪出相应的人脸图像
            face_image = frame[y:y + h, x:x + w]
            # cv2.imwrite("tempimage444.jpg", face_image)
            unknown_face_encodings = face_recognition.face_encodings(np.array(face_image))[0]

            # test code👇
            # allface = []
            # allface.append(np.array(unknown_face_encodings))
            # imgasd = face_recognition.load_image_file("tempimage0.9133255717643947.jpg")
            # imgasd123412412 = face_recognition.load_image_file("gew20231221133340.jpg")

            # Get face encodings for any faces in the uploaded image
            # unknown_face_encodings = face_recognition.face_encodings(imgasd, model='large')

            # unknown_face_encodings1231 = face_recognition.face_encodings(imgasd123412412, model='large')
            # allface.append(np.array(np.array(unknown_face_encodings1231)[0]))
            # match_results,weizhi = face_recognition.compare_faces(allface, unknown_face_encodings[0], 0.25)
            # # 暂时阈值给0.25测试
            # print(match_results,weizhi)

            return JSONResponse(content={"code": 1, "face_data": json.dumps(unknown_face_encodings.tolist())})
    # Open the image using PIL
    # Process the image (e.g., get image size)
    # Return the processed data as JSON
    return JSONResponse(content={"code": 0})

# uvicorn face2recognition_api:app --reload
