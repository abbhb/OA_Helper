search_uri = "/home/ai/face_id_client/examples/search.html"
# 相对路径假如运行用的python example/find_face_qt_v2.py就用的根目录的数据库 直接进example里python find_face_qt_v2.py就是这个目录，所以写死
db_uri = "/home/ai/face_id_client/examples/face_data.db"

server_port = 25401
secert = "rt34y54.14ertgf"
my_ip = "10.15.246.241"
service_id = "4y35rwu7456"
consul_server_ip = "192.168.12.12"
consul_server_port = 18500
java_server_ip = "10.15.247.223"
